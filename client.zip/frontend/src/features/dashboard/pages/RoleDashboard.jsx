import { useCallback } from 'react'
import { useAuth } from '../../../auth/useAuth'
import { ROLE_LABELS } from '../../../auth/roles'
import { QuickActions, SectionCard, StatGrid, ProjectList, WelcomeBanner } from '../components'
import { Link } from 'react-router-dom'
import { useAsync } from '../../../hooks/useAsync'
import { dashboardService } from '../services/dashboardService'
import { ApiErrorMessage } from '../../auth/components/ApiErrorMessage'

// Agency dashboard layout; the role page supplies copy and quick actions.
export function RoleDashboard({
  subtitle,
  actions,
  ticketsLink,
  ticketsTitle = 'Recent projects',
  showAgency = true,
  additionalStats = [],
  additionalStatsLoading = false,
  additionalStatsError = null,
  onRetryAdditionalStats,
  attention = null,
}) {
  const { user } = useAuth()
  const tickets = useAsync(useCallback(() => dashboardService.getDashboard({ user }), [user]))
  const stats = tickets.data ? dashboardService.getStats(tickets.data.summary) : []
  const firstName = user.name?.split(' ')[0] ?? 'there'

  return (
    <section className="page dashboard">
      <WelcomeBanner eyebrow={ROLE_LABELS[user.role]} title={`Welcome back, ${firstName}`} subtitle={subtitle}>
        {ticketsLink && <Link to={ticketsLink} className="ui-button ui-button-secondary ui-button-sm">View work</Link>}
      </WelcomeBanner>
      {(stats.length > 0 || additionalStats.length > 0) && (
        <StatGrid stats={[...stats, ...additionalStats]} isLoading={tickets.isLoading || additionalStatsLoading} />
      )}
      <ApiErrorMessage error={additionalStatsError} />
      {additionalStatsError && onRetryAdditionalStats && (
        <button type="button" className="inline-link" onClick={onRetryAdditionalStats}>Retry loading employee stats</button>
      )}
      {attention}
      <div className="dashboard-columns">
        <SectionCard title={ticketsTitle} description="Recently scheduled and assigned work">
          {tickets.error
            ? <p role="alert" className="form-error">Could not load assigned work. <button type="button" className="inline-link" onClick={tickets.reload}>Try again</button></p>
            : <ProjectList tickets={(tickets.data?.projects ?? []).slice(0, 5)} isLoading={tickets.isLoading} showAgency={showAgency} />}
        </SectionCard>
        <div className="dashboard-side">
          <SectionCard title="Quick actions"><QuickActions actions={actions} /></SectionCard>
        </div>
      </div>
    </section>
  )
}
