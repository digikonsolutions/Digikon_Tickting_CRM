<?php echo e($slot); ?>

<?php /**PATH D:\client\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>