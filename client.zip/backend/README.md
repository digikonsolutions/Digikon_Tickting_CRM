<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## ClientHub API and authentication

The API uses Laravel's server-side session guard for the first-party React SPA. Authentication endpoints are under `/api/auth`; the browser must first request `/api/auth/csrf-cookie`, then send the `X-XSRF-TOKEN` header on state-changing requests. The frontend auth service handles this when `VITE_AUTH_MODE=api`. Public registration is disabled: only an authenticated administrator can create accounts.

Configure the backend `.env` with:

```env
APP_URL=http://localhost:8000
FRONTEND_URL=http://localhost:5173
SESSION_DRIVER=database
SESSION_SECURE_COOKIE=false
MAIL_MAILER=log
```

Copy `frontend/.env.example` to `frontend/.env.local` (it already contains these values) or set:

```env
VITE_API_URL=http://localhost:8000/api
VITE_AUTH_MODE=api
```

Run `php artisan migrate` before starting the application. In local development, password-reset links are written to `storage/logs/laravel.log` when `MAIL_MAILER=log`. Configure a production mail provider, HTTPS, secure cookies, a restricted `FRONTEND_URL`, and appropriate session domain settings before deployment.

There is no default admin account or public signup route. Bootstrap the first administrator from trusted local tooling with `php artisan app:create-admin "Administrator" admin@example.com`; the command prompts for a strong password without echoing it. For local-only seeding, set `LOCAL_ADMIN_NAME`, `LOCAL_ADMIN_EMAIL`, and `LOCAL_ADMIN_PASSWORD` in the local environment before running `php artisan db:seed`. Do not set these values in production.

Available routes:

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/auth/csrf-cookie` | Establish the CSRF/session cookies |
| PATCH | `/api/auth/profile` | Any signed-in, active user updates their own display name (trimmed, whitespace collapsed, max 120). `email`, `role`, `agency_id`, `is_active` and `password` are rejected with 422. The only self-service profile route; the former `/api/agency/profile` was removed |
| PUT | `/api/auth/password` | Change your own password: `current_password`, `password` (reset-flow policy, must differ) and `password_confirmation`. Ends every other session, rotates the remember token and the current session id. Throttled to 5 a minute per user |
| POST | `/api/auth/users` | Admin-only account invitation; role and agency assignment are validated |
| GET | `/api/admin/users` | Admin-only paginated directory of all roles (optionally filtered by `role`); supports `search`, `page`, and `per_page` |
| PATCH | `/api/admin/users/{user}` | Admin update of employee or agency-owner details and activation |
| DELETE | `/api/admin/users/{user}` | Admin permanent deletion of an employee or agency owner |
| PATCH | `/api/admin/agencies/{agency}` | Admin activates or suspends an agency; suspension revokes its users' sessions |
| GET | `/api/agency/users` | Agency-owner list of agency accounts; employee accounts are read-only |
| POST | `/api/agency/users` | Agency owners invite clients into their active agency |
| PATCH | `/api/agency/users/{user}` | Owners update same-agency client details and activation |
| DELETE | `/api/agency/users/{user}` | Owners delete same-agency clients |
| GET | `/api/agency/directory` | Agency-owner, legacy agency-member, and agency-client directory including shared admin-created employees |
| GET | `/api/agency/team` | Agency-owner/client roster of shared admin-created employees |
| GET | `/api/agency/employees/available` | Agency client/owner list of active same-agency and shared employees with no active holder |
| POST | `/api/agency/assignments` | Hold an available employee exclusively for the current client or owner |
| GET | `/api/agency/assignments` | List the caller's own active assignments (holder only; `scope` is rejected with 422) |
| GET | `/api/agency/assignments/{assignment}/usage` | Read usage of an assignment the caller holds for a requested `?week=YYYY-MM-DD` (404 otherwise) |
| DELETE | `/api/agency/assignments/{assignment}` | Holder ends their own assignment (owners and clients alike; 404 for anyone else's) |
| GET | `/api/agency/projects` | Agency clients and owners page through projects in their agency. Query: `page`, `per_page` (default 25, max 100), `status` (`open`, `scheduled`, `in_progress`, `completed`, `cancelled`; `open` = scheduled + in progress), `assignment_id`, `search` (title, client or employee name). Returns `projects`, `pagination` and an agency-wide `summary` of counts by status that ignores filters and page |
| GET | `/api/agency/capacity?assignment_id=&from=&to=` | Agency client/owner read per-day availability of an employee they hold (same rules as the scheduler) for a date range of up to 366 days |
| GET | `/api/agency/projects/{workItem}` | Agency clients and owners read one project in their agency (404 for other agencies) |
| POST | `/api/agency/projects` | Agency client/owner create a project using their active `assignment_id` |
| PATCH | `/api/agency/projects/{workItem}/cancel` | Agency clients and owners cancel any open project in their agency |
| GET | `/api/agency/projects/{workItem}/tickets` | Agency clients and owners read tickets for projects in their agency |
| POST | `/api/agency/projects/{workItem}/tickets` | Agency clients and owners create tickets and plan them against project capacity |
| PATCH | `/api/agency/projects/{workItem}/tickets/reorder` | Reorders a project's tickets and recalculates their dates |
| PATCH | `/api/agency/tickets/{ticket}` | Agency clients and owners update tickets on projects in their agency |
| DELETE | `/api/agency/tickets/{ticket}` | Agency owner/client cancels a ticket and replans remaining tickets |
| GET | `/api/work-items/mine/tickets` | Employee reads tickets for their assigned projects |
| PATCH | `/api/tickets/{ticket}/status` | Assigned employee advances a ticket through its status flow |
| GET | `/api/tickets/{ticket}/comments` | Same access as posting (admin, the ticket's assigned employee, agency owners/clients of its active agency; others 403). Returns `{ comments, total }`: the latest 200 comments oldest first, each with `user: {id, name, role}` |
| POST | `/api/tickets/{ticket}/comments` | Authorized project participants or admins add a ticket comment (same access rule as reading) |
| GET | `/api/tickets/key/{key}` | Open a ticket by its human key (`PREFIX-n`, parsed on the last hyphen). Returns `{ticket, project, timeline}` (first 25 events). Admin, the assigned employee, or an owner/client of the ticket's active agency; anyone else gets 404 |
| GET | `/api/tickets/{ticket}/timeline` | Cursor-paginated activity timeline, newest first (`events`, `next_cursor`). Same access as the key route; internal items are filtered in SQL for agency roles |
| POST | `/api/tickets/{ticket}/transitions` | `{action, comment?}`: run a workflow action from `TicketWorkflow` (start, send_to_review, mark_blocked, unblock, request_client_input, provide_input, approve, request_changes, restart_work). Required comments are saved as public comments linked to the `status_changed` event |
| GET | `/api/agency/attention` | Agency owner/client: up to 5 tickets waiting on the client (in review or asking a question), longest-waiting first, plus `total` |
| GET | `/api/admin/tickets` | Admin read-only paginated ticket directory |
| GET | `/api/work-items/mine` | Employee list of assigned projects |
| GET | `/api/admin/projects` | Admin read-only, searchable paginated view of all projects and schedules |
| GET | `/api/admin/dashboard?status=` | Admin dashboard summary in one call: project counts by status, ticket total, scheduled hours per day for the next 7 days (excludes cancelled/completed) and the 4 most recent projects, optionally filtered by `status` |
| GET | `/api/admin/assignments` | Admin read-only paginated employee-assignment directory |
| DELETE | `/api/admin/assignments/{assignment}` | Admin ends an assignment and releases its future work allocations |
| POST | `/api/auth/login` | Sign in |
| POST | `/api/auth/logout` | End the current session |
| GET | `/api/auth/me` | Return the authenticated user and role |
| POST | `/api/auth/forgot-password` | Request a reset link |
| POST | `/api/auth/reset-password` | Reset password with a time-limited token |
| GET | `/api/notifications?unread=1&cursor=` | The caller's own notifications, newest first, cursor-paginated (`notifications`, `next_cursor`, `unread_count`) |
| GET | `/api/notifications/unread-count` | `{count}` for the header bell |
| POST | `/api/notifications/{id}/read` | Mark one notification read (404 unless it belongs to the caller) |
| POST | `/api/notifications/read-all` | Mark every notification read |
| GET / PUT | `/api/notifications/preferences` | Per-type in-app and email switches (`needs_input` in-app is locked on) |
| GET | `/api/tickets/{ticket}/attachments` | Attachments the viewer may see (internal ones are hidden from agency roles), plus the upload limits |
| POST | `/api/tickets/{ticket}/attachments` | Multipart `files[]` (+ optional `comment`, `is_internal`) |
| GET | `/api/attachments/{attachment}/download` | Streams the file through Laravel after the ticket authorization check; `?inline=1` only for png/jpeg/gif/webp |
| DELETE | `/api/attachments/{attachment}` | Soft-deletes an attachment (the uploader, an admin, or the ticket's agency owner) |
| POST | `/api/tickets/{ticket}/time/start` | Assigned employee starts a timer (in progress or changes requested only); starting another stops the first |
| POST | `/api/time/stop` | Stop the employee's running timer and log the time |
| GET | `/api/time/active` | The employee's running timer plus `server_time` for clock correction |
| POST | `/api/tickets/{ticket}/time` | Assigned employee logs a manual entry `{entry_date, minutes, note?}` |
| PATCH / DELETE | `/api/time/{entry}` | Employee changes their own entry for 48 h; admins may always, but must send a `reason` |
| GET | `/api/tickets/{ticket}/time` | Entries (hidden from agency roles when `time.agency_sees_entries` is false) and totals |
| GET | `/api/time/week?week=YYYY-MM-DD` | Employee timesheet, Monday to Saturday: logged versus scheduled per day and per ticket |
| GET | `/api/admin/time-summary` | `from`, `to`, `group_by=employee\|agency\|project`, optional `format=csv` |
| GET | `/api/agency/time-summary` | Agency owner: same, for their own agency, `group_by=employee\|project` |

Roles are `admin`, `team_lead`, `employee`, `qa`, `agency_owner`, `agency_member` (legacy), and `agency_client`. Only admins can create or manage employee accounts. Employee accounts may be linked to an agency or remain shared with a null agency ID. Admins can also create and manage agency owners. When an admin creates an agency owner, the request includes the agency name and the backend creates the agency and owner together; the database generates the agency ID. Agency owners can manage clients in their own agency, but employee accounts are view-only. Agency owners and clients can hold multiple employees, but each employee can have only one active holder at a time. Assignments are private to their holder: owners and clients can only list, read usage or capacity for, and end the assignments they hold themselves (there is no agency-wide assignment view, and owners cannot release a client's employee); admins see and end every assignment through `/api/admin/assignments`, and projects stay visible to the whole agency. Deactivating or deleting a holder automatically ends the assignments they hold (cancelling the open projects on them and releasing their future hours), so an employee can never stay held by an account that cannot release them. Shared employees become unavailable to all other agencies while held. Agency roles and tenant IDs are assigned by the backend, never trusted from client input. Invited users receive a password setup email and set their own password through the existing password-reset flow. The `agency_id` and role returned by `/api/auth/me` are for frontend menus only; backend routes enforce authorization and tenant scoping. Agency-facing routes (team, directory, profile, agency users, employee holds, capacity and projects) run the `agency.active` middleware after `auth` and `role:`, which returns 403 when the caller has no agency or their agency is suspended. Ticket routes intentionally keep their own check and answer 404, and employee routes still allow a null agency.

Agency clients and owners create projects against an active employee assignment they hold. A project is limited to 180 estimated hours, and each client may have at most three open projects. The scheduler allocates earliest-first Monday through Saturday, skips Sundays and the `non_working_dates` configured in `config/scheduling.php`, and caps each employee at six hours per workday (36 hours per week). Today's capacity is available only before `today_cutoff_hour` (default 12) in the configured application timezone. Capacity checks and reservations are enforced transactionally; cancelled projects and ended assignments release allocations dated today or later. `GET /api/agency/capacity` returns the per-day availability the scheduler would use for a held employee (Sundays, non-working dates, today after the cutoff hour, the 6 h daily cap and bookings from every agency), so the UI never has to repeat that maths. Project payloads include `tickets_total`, `tickets_done`, `tickets_open` (cancelled tickets excluded) and `next_ticket` (the first non-done, non-cancelled ticket by position, or `null`). Clients and owners can see project details, employee selections, and statuses within their own agency; clients may create projects only against assignments they hold. Employees do not set project status directly: a project moves to in-progress when its first ticket starts and to completed when all of its non-cancelled tickets are done; admins can view all projects but cannot edit them.

Capacity rules live in `config/scheduling.php`: `daily_capacity_hours` (6), `weekly_capacity_hours` (36) and `working_days` (ISO weekdays 1 to 6, Monday to Saturday), next to `non_working_dates` and `today_cutoff_hour`. The scheduler, usage reports and capacity endpoint all read these keys, and assignment payloads (`capacity: {daily_hours, weekly_hours}`) and `GET /api/work-items/mine` expose them so the UI never hardcodes them. Weekly usage reports `used` (every non-cancelled hour booked on the assignment that week, completed work included), `remaining` (weekly capacity minus `used`) and `bookable_remaining` (what the scheduler would still accept for that employee that week: completed and cancelled bookings are freed, Sundays, non-working dates, past days and today after the cutoff are skipped, and every agency's bookings count). Ticket payloads include `creator: {id, name}` (or `null` when that account was deleted).

Every ticket has a human key (`PREFIX-n`, for example `NORT-42`): each agency gets an immutable `ticket_prefix` (generated from its name, locked once tickets exist) and a `ticket_sequence`, and numbers are allocated under a row lock inside the ticket-creation transaction. Every change is written to the append-only `ticket_events` timeline (created, updated, status_changed, rescheduled, reordered, cancelled, comment) with actor name and role snapshots, so history survives user deletion; system-triggered changes use a null actor named "System". Events can never be updated or deleted. Comments may be `is_internal` (admin and the assigned employee only; agency roles can neither create nor read them, filtered in SQL). When the planner moves a ticket's dates it records a `rescheduled` event with a plain-English reason, and the `update` and `reorder` responses include `rescheduled: [{key, from, to, reason}]`. Statuses are todo, in_progress, in_review, blocked, waiting_on_client, changes_requested, done and cancelled. `TicketWorkflow` is the single transition table: employees start, send to review, block, ask the client and rework; only the client (an owner or client of the ticket's agency) approves, requests changes or answers questions. With `scheduling.require_client_approval` (default true) the employee can no longer move a ticket from in_review to done (422); set it to false to restore the old behaviour. Ticket payloads carry `key`, `allowed_actions` (computed for the viewer), `waiting_on` (`client` for in_review and waiting_on_client, `employee` for todo, in_progress and changes_requested, `team` for blocked), `waiting_since` and `status_reason`. Blocked and waiting tickets keep their scheduled hours. The admin ticket list accepts `status`, `agency_id`, `employee_id`, `waiting_on` and `search` (key or title).
Tickets are hour slices of a project's existing schedule and inherit its employee assignment. Agency clients and owners may create, edit, reorder, and cancel tickets for any project in their own agency while its assignment is active and the project remains open. Tickets are planned earliest-first within the project's allocated dates, and their combined hours cannot exceed the project's estimated hours. The assigned employee advances tickets through `todo` → `in_progress` → `in_review` → `done`; ticket progress updates the project status. Project cancellation cancels its tickets and removes all ticket allocations.

### Running the queue worker and scheduler

Notifications and their emails are queued (`QUEUE_CONNECTION=database`, `afterCommit`), so **`php artisan queue:work` must be running** or nobody receives anything. `composer dev` already starts `queue:listen`. Time tracking needs the scheduler: the hourly `time:stop-stale-timers` command closes timers that ran past 12 hours. Locally run `php artisan schedule:work`; in production add the usual cron entry `* * * * * php artisan schedule:run`. Locally `MAIL_MAILER=log` writes emails to `storage/logs/laravel.log`.

### Notifications

Every ticket event is turned into notifications by one listener (`SendTicketNotifications` on `TicketEventRecorded`). The actor is never notified, inactive users get nothing, and internal comments only ever reach admins and the assigned employee (in-app, email and API alike). Payload: `{type, ticket_id, ticket_key, title, body, url_path, actor_name}`.

| Event | Recipients | Class |
|---|---|---|
| Public comment | the other side (employee when a client commented; the ticket creator and agency owner when the employee or an admin did) | `TicketCommented` |
| Internal comment | admins and the assigned employee | `TicketCommented` |
| Moved to in review | ticket creator and agency owner | `TicketNeedsYourInput` |
| Moved to waiting on client | ticket creator and agency owner | `TicketNeedsYourInput` |
| Changes requested | assigned employee | `TicketStatusChanged` |
| Blocked | agency owner and admins | `TicketStatusChanged` |
| Done | assigned employee and ticket creator | `TicketStatusChanged` |
| Rescheduled | ticket creator and agency owner, one notification per ticket per planner run | `TicketRescheduled` |
| Cancelled | ticket creator and assigned employee (unless they cancelled it) | `TicketCancelled` |
| Created | assigned employee | `TicketAssigned` |

Repeat notifications of the same type for the same ticket within 10 minutes are coalesced into one unread row with a `count`. Preferences default to in-app on for everything and email on only for "needs your input" and "rescheduled"; the in-app switch for "needs your input" cannot be turned off. Emails carry a `[KEY] Title` subject, a one-line summary, at most 200 characters of the public comment, a button to `FRONTEND_URL` + `url_path` and a footer link to `/settings/notifications`.

### Attachments

Files are stored on a private disk (`config/attachments.php`, never `public`) under UUID names and are only reachable through `GET /api/attachments/{id}/download`, which re-checks ticket access, sends `X-Content-Type-Options: nosniff` and `Content-Disposition: attachment` (inline only for png/jpeg/gif/webp). The file content is sniffed with `finfo` and must agree with the extension; svg, html, js, php and executables are rejected, zip only when `ATTACHMENTS_ALLOW_ARCHIVES=true`. Attachments are scanned through the `AttachmentScanner` contract (`NullScanner` by default; bind a real one such as ClamAV in `AppServiceProvider`). Adding or removing a file records an `attachment_added` / `attachment_removed` event (internal when the file is internal).

| Key (`config/attachments.php`) | Env | Default |
|---|---|---|
| `disk` | `ATTACHMENTS_DISK` | `local` |
| `max_file_kb` | `ATTACHMENTS_MAX_FILE_KB` | 10240 |
| `max_files_per_upload` | `ATTACHMENTS_MAX_FILES_PER_UPLOAD` | 10 |
| `max_files_per_ticket` | `ATTACHMENTS_MAX_FILES_PER_TICKET` | 50 |
| `allow_archives` | `ATTACHMENTS_ALLOW_ARCHIVES` | false |
| `temporary_urls`, `temporary_url_minutes` | `ATTACHMENTS_TEMPORARY_URLS`, `ATTACHMENTS_TEMPORARY_URL_MINUTES` | false, 5 (S3-style disks only) |

PHP limits apply before Laravel does: set `upload_max_filesize` and `post_max_size` in `php.ini` at least to `max_file_kb` times `max_files_per_upload` (for example `12M` and `110M`), and `max_file_uploads` to at least 10. A request over `post_max_size` arrives empty and fails with a validation error.

### Time tracking

Only the employee assigned to a ticket logs time; admins can correct or remove entries but must give a reason; agency users are read-only. Rules live in `config/time.php`:

| Key | Env | Default | Meaning |
|---|---|---|---|
| `timer_statuses` | | in_progress, changes_requested | statuses in which a timer can run |
| `max_timer_hours` | | 12 | the hourly command closes older timers at exactly this length and flags them `auto_stopped` |
| `min_entry_minutes`, `max_entry_minutes` | | 1, 720 | size of one manual entry |
| `max_days_back` | | 14 | oldest date an employee may log for (admins are exempt); never future dates |
| `max_daily_hours` | | 16 | total per employee per day |
| `edit_window_hours` | | 48 | how long an employee can edit or delete their own entry |
| `agency_sees_entries` | `TIME_AGENCY_SEES_ENTRIES` | true | when false agency users see totals but not the individual entries |

There is one running timer per employee: starting another stops the first. Timers also stop automatically when the ticket moves to blocked, waiting on client, in review or done, when it is cancelled, when the project is cancelled, when the assignment ends and when the employee is deactivated (the stop reason is stored). Each manual entry and each stopped timer records one public `time_logged` event; starting a timer records nothing. Overruns are only flagged (`over_estimate`); nothing is rescheduled automatically. Ticket payloads carry `logged_hours`, `estimated_hours`, `over_estimate` and `timer_running`. Summaries aggregate in SQL and return, per group, logged, scheduled and estimated hours plus utilization (logged divided by scheduled); `format=csv` streams a download with spreadsheet formula characters neutralised.

### Employee activity (admin only)

Employee sign-ins, sign-outs, ticket status changes, comment events (never their text), project status changes and idle periods are written to `employee_activity_logs` by one `ActivityLogger` service; the server picks every event type and timestamp. A `work_sessions` row starts at login and ends at logout, or after `ACTIVITY_SESSION_TIMEOUT_MINUTES` (10) without a heartbeat (`php artisan activity:maintain`, scheduled every five minutes, also prunes rows older than `ACTIVITY_RETENTION_DAYS`). The employee UI sends `POST /api/employee/heartbeat` about once a minute while the tab is visible with only an `idle` flag (no interaction for `ACTIVITY_IDLE_AFTER_MINUTES`, default 5); the server measures the elapsed time itself and caps each beat at 120 s. No keystrokes, screenshots or page content are collected. `GET /api/admin/employees/{id}/activity` (paginated; `from`, `to`, `event_type`) and `GET /api/admin/employees/{id}/performance` (daily and weekly active, logged and scheduled hours, tickets completed, average logged hours per completed ticket, late and early first sign-ins against `ACTIVITY_WORKDAY_START`) are admin-only; every other role gets 403. Employees see a one-line notice at first sign-in and in the invite email.

### Project and ticket briefs

Projects accept optional `objective`, `deliverables`, `target_url`, `staging_url`, `repo_url`, `platform` (ghl, wordpress, custom, other), `tech_stack`, `brand_assets_url`, `access_details`, `reference_links`, `acceptance_criteria`, `budget`, `brief_priority`, `contact_name` and `contact_email`. Links must be http(s). `access_details` is encrypted at rest and returned only by single-project reads (agency, admin and the assigned employee), never in lists. Tickets accept `steps_to_reproduce`, `expected_result`, `actual_result`, `affected_url`, `environment`, `severity`, `due_preference` and `related_ticket_ids` (same project only); `due_preference` is a hint, the planner still schedules. Project files live in the polymorphic `attachments` table on the private disk (`GET/POST /api/projects/{id}/attachments`, `GET /api/project-attachments/{id}/download`, `DELETE /api/project-attachments/{id}`): the agency's owner and clients upload, the agency, the assigned employee and admins download, everyone else gets 404. Project briefs also accept zip (`ATTACHMENTS_BRIEF_ALLOW_ARCHIVES`, default true); ticket files keep the stricter `ticket_attachments` rules.
### Testing with Postman

Use the same host consistently throughout this flow (for example, `http://127.0.0.1:8000`). In Postman, enable its cookie jar for that host, and add these headers to JSON requests:

```text
Accept: application/json
Content-Type: application/json
X-XSRF-TOKEN: <URL-decoded value of the XSRF-TOKEN cookie>
```

1. Start Laravel with `php artisan serve`, and run `php artisan migrate`.
2. Create the first admin from a trusted terminal with `php artisan app:create-admin "Administrator" admin@example.com`.

3. In Postman, send `GET http://127.0.0.1:8000/api/auth/csrf-cookie`. Postman should retain the `laravel_session` and `XSRF-TOKEN` cookies. Copy the `XSRF-TOKEN` cookie value, URL-decode it, and use it in the `X-XSRF-TOKEN` header for the following POST requests. Keep Postman’s cookie jar enabled so the session cookie is sent too.
4. Send `POST http://127.0.0.1:8000/api/auth/login` with:

   ```json
   {
     "email": "admin@example.com",
     "password": "Your-Strong-Local-Password!"
   }
   ```

5. Confirm the session with `GET http://127.0.0.1:8000/api/auth/me`.
6. As the admin, invite an employee with `POST http://127.0.0.1:8000/api/auth/users`:

   ```json
   {
     "name": "Employee",
     "email": "employee@example.com",
     "role": "employee"
   }
   ```

   Valid roles are `admin`, `team_lead`, `employee`, `qa`, `agency_owner`, `agency_member`, and `agency_client`. Employee accounts are created by admins and are shared across agencies. Agency owners can invite clients through `/api/agency/users`; the backend always assigns the owner's agency. An unauthenticated request returns 401; a signed-in user without the required role returns 403.
7. Test `POST /api/auth/forgot-password` with `{"email":"admin@example.com"}`. With `MAIL_MAILER=log`, find the reset URL in `storage/logs/laravel.log`; submit its `token` and `email` with `password` and `password_confirmation` to `POST /api/auth/reset-password`.
8. Send `POST /api/auth/logout`, then verify `GET /api/auth/me` returns 401.

Refresh the CSRF-cookie request and update the token header if Postman reports a CSRF mismatch. Do not send real credentials to a shared Postman workspace or commit them into a collection.

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework.

You may also try the [Laravel Bootcamp](https://bootcamp.laravel.com), where you will be guided through building a modern Laravel application from scratch.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains thousands of video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the [Laravel Partners program](https://partners.laravel.com).

### Premium Partners

- **[Vehikl](https://vehikl.com/)**
- **[Tighten Co.](https://tighten.co)**
- **[WebReinvent](https://webreinvent.com/)**
- **[Kirschbaum Development Group](https://kirschbaumdevelopment.com)**
- **[64 Robots](https://64robots.com)**
- **[Curotec](https://www.curotec.com/services/technologies/laravel/)**
- **[Cyber-Duck](https://cyber-duck.co.uk)**
- **[DevSquad](https://devsquad.com/hire-laravel-developers)**
- **[Jump24](https://jump24.co.uk)**
- **[Redberry](https://redberry.international/laravel/)**
- **[Active Logic](https://activelogic.com)**
- **[byte5](https://byte5.de)**
- **[OP.GG](https://op.gg)**

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
